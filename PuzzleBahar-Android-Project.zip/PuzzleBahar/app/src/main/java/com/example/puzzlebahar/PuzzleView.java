package com.example.puzzlebahar;
import android.graphics.*;import android.graphics.drawable.*;import android.view.*;import android.content.*;import java.util.*;import org.json.*;

public class PuzzleView extends View {
 Bitmap src; int rows,cols,n; Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); Paint text=new Paint(Paint.ANTI_ALIAS_FLAG); ArrayList<Piece> ps=new ArrayList<>(); Random rnd=new Random(); int selected=-1; float downX,downY,oldX,oldY; float boardL,boardT,boardW,boardH,cellW,cellH; SharedPreferences pref; boolean fresh;
 class Piece{int idx,r,c;float x,y;boolean locked=false;Piece(int i,int rr,int cc){idx=i;r=rr;c=cc;}}
 public PuzzleView(Context c,Bitmap b,int rr,int cc,boolean f){super(c);src=b;rows=rr;cols=cc;n=rr*cc;fresh=f;pref=c.getSharedPreferences("puzzle",0);setLayerType(View.LAYER_TYPE_SOFTWARE,null); text.setTypeface(Typeface.create("sans",Typeface.BOLD)); if(f){makePieces();}else restore();}
 void makePieces(){for(int i=0;i<n;i++){int r=i/cols,c=i%cols;Piece q=new Piece(i,r,c);q.x=rnd.nextFloat()*.75f;q.y=.22f+rnd.nextFloat()*.68f;ps.add(q);} }
 void restore(){try{makePieces();String s=pref.getString("state","");if(s.length()>0){JSONArray a=new JSONArray(s);for(int i=0;i<n;i++){JSONObject o=a.getJSONObject(i);Piece q=ps.get(i);q.x=(float)o.getDouble("x");q.y=(float)o.getDouble("y");q.locked=o.getBoolean("l");}}}catch(Exception e){makePieces();}}
 protected void onDraw(Canvas c){super.onDraw(c);c.drawColor(Color.rgb(255,249,244));
   boardL=18;boardT=86;boardW=getWidth()-36;boardH=Math.min(getHeight()-110,boardW*src.getHeight()/(float)src.getWidth());cellW=boardW/cols;cellH=boardH/rows;
   p.setShadowLayer(10,0,4,0x33000000);p.setColor(Color.WHITE);c.drawRoundRect(boardL,boardT,boardL+boardW,boardT+boardH,22,22,p);p.clearShadowLayer();
   text.setTextSize(18);text.setColor(Color.rgb(80,60,65));c.drawText("🌸 پازل بهار",20,38,text);text.setTextSize(12);c.drawText("قطعات: "+n,20,62,text);
   // guide
   float gw=Math.min(120,boardW*.23f), gh=gw*src.getHeight()/src.getWidth();float gx=getWidth()-gw-18,gy=10; p.setAlpha(210);c.drawBitmap(src,null,new RectF(gx,gy,gx+gw,gy+gh),p);p.setAlpha(255);
   for(Piece q:ps) drawPiece(c,q);
 }
 void drawPiece(Canvas c,Piece q){float x,y;if(q.locked){x=boardL+q.c*cellW;y=boardT+q.r*cellH;}else{x=boardL+q.x*boardW;y=boardT+q.y*boardH;}
   RectF dst=new RectF(x+2,y+2,x+cellW-2,y+cellH-2);p.setStyle(Paint.Style.FILL);p.setShadowLayer(5,0,2,0x55000000);Path clip=new Path();clip.addRect(dst,Path.Direction.CW);c.save();c.clipPath(clip);float sx=q.c*src.getWidth()/cols, sy=q.r*src.getHeight()/rows, sw=src.getWidth()/cols, sh=src.getHeight()/rows;c.drawBitmap(src,new Rect((int)sx,(int)sy,(int)(sx+sw),(int)(sy+sh)),dst,p);c.restore();p.clearShadowLayer();p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1);p.setColor(0x55FFFFFF);c.drawRect(dst,p);p.setStyle(Paint.Style.FILL);
 }
 int hit(float x,float y){for(int i=n-1;i>=0;i--){Piece q=ps.get(i);float px=q.locked?boardL+q.c*cellW:boardL+q.x*boardW,py=q.locked?boardT+q.r*cellH:boardT+q.y*boardH;if(!q.locked&&x>=px&&x<=px+cellW&&y>=py&&y<=py+cellH)return i;}return -1;}
 public boolean onTouchEvent(android.view.MotionEvent e){float x=e.getX(),y=e.getY();if(e.getAction()==MotionEvent.ACTION_DOWN){selected=hit(x,y);downX=x;downY=y;oldX=x;oldY=y;if(selected>=0){Piece q=ps.remove(selected);ps.add(q);selected=ps.size()-1;invalidate();}return true;}if(e.getAction()==MotionEvent.ACTION_MOVE&&selected>=0){Piece q=ps.get(selected);q.x+=((x-oldX)/boardW);q.y+=((y-oldY)/boardH);oldX=x;oldY=y;invalidate();return true;}if(e.getAction()==MotionEvent.ACTION_UP&&selected>=0){Piece q=ps.get(selected);snap(q);persist();selected=-1;invalidate();return true;}return true;}
 void snap(Piece q){float tx=q.c/(float)cols,ty=q.r/(float)rows;float dx=q.x-tx,dy=q.y-ty;float threshold=Math.max(.018f,Math.min(.055f,1.8f/Math.max(rows,cols)));if(Math.hypot(dx,dy)<threshold){q.x=tx;q.y=ty;q.locked=true;if(isComplete()){Bitmap out=Bitmap.createBitmap(src.getWidth(),src.getHeight(),Bitmap.Config.ARGB_8888);Canvas cc=new Canvas(out);cc.drawBitmap(src,0,0,p);((MainActivity)getContext()).saveCompleted(out);pref.edit().remove("state").apply();}}}
 boolean isComplete(){for(Piece q:ps)if(!q.locked)return false;return true;}
 void persist(){try{JSONArray a=new JSONArray();for(Piece q:ps){JSONObject o=new JSONObject();o.put("x",q.x);o.put("y",q.y);o.put("l",q.locked);a.put(o);}pref.edit().putString("state",a.toString()).apply();}catch(Exception ignored){}}
}
