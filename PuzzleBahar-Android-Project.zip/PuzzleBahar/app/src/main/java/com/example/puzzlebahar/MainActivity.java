package com.example.puzzlebahar;

import android.app.*;import android.os.*;import android.content.*;import android.graphics.*;import android.graphics.drawable.ColorDrawable;import android.net.Uri;import android.provider.MediaStore;import android.view.*;import android.widget.*;import java.io.*;import java.util.*;

public class MainActivity extends Activity {
    PuzzleView puzzle;
    int rose=Color.rgb(169,87,106), cream=Color.rgb(255,249,244), sage=Color.rgb(157,183,162);
    @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(cream); getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR); showHome();}
    TextView tv(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(Color.rgb(80,60,65));t.setGravity(Gravity.CENTER);t.setPadding(18,12,18,12);return t;}
    void showHome(){
      LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setGravity(Gravity.CENTER_HORIZONTAL);root.setPadding(24,30,24,24);root.setBackgroundColor(cream);
      TextView title=tv("🌸  پازل بهار",30);title.setTextColor(rose);root.addView(title,new LinearLayout.LayoutParams(-1,80));
      TextView sub=tv("عکس خودت را انتخاب کن و پازلش را بساز",16);root.addView(sub,new LinearLayout.LayoutParams(-1,60));
      Button photo=new Button(this);photo.setText("📷  انتخاب عکس از گوشی");photo.setTextSize(17);photo.setTextColor(Color.WHITE);photo.setBackgroundColor(rose);root.addView(photo,new LinearLayout.LayoutParams(-1,60));
      Button resume=new Button(this);resume.setText("▶  ادامه آخرین پازل");resume.setTextSize(17);root.addView(resume,new LinearLayout.LayoutParams(-1,60));
      TextView info=tv("آفلاین • ذخیره خودکار • تا ۲۰۰ قطعه",14);info.setTextColor(sage);root.addView(info,new LinearLayout.LayoutParams(-1,70));
      photo.setOnClickListener(v->pickImage()); resume.setOnClickListener(v->{if(hasSaved()){loadSaved();}else Toast.makeText(this,"هنوز پازل ذخیره‌شده‌ای ندارید",Toast.LENGTH_SHORT).show();});
      setContentView(root);
    }
    boolean hasSaved(){return getSharedPreferences("puzzle",0).contains("imagePath")&&getSharedPreferences("puzzle",0).contains("rows");}
    void pickImage(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,44);}
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==44&&c==RESULT_OK&&d!=null&&d.getData()!=null){try{Uri u=d.getData();getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);File f=new File(getFilesDir(),"puzzle_source.jpg");InputStream in=getContentResolver().openInputStream(u);FileOutputStream out=new FileOutputStream(f);byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)out.write(buf,0,n);in.close();out.close();choosePieces(f.getAbsolutePath());}catch(Exception e){Toast.makeText(this,"خواندن عکس انجام نشد",Toast.LENGTH_SHORT).show();}}}
    void choosePieces(String path){
      final String[] vals={"4","6","12","20","30","48","60","80","100","120","150","200"};
      Spinner sp=new Spinner(this);ArrayAdapter<String>a=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,vals);sp.setAdapter(a);
      LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(30,20,30,10);TextView t=tv("تعداد قطعات را انتخاب کن",20);box.addView(t);box.addView(sp);
      new AlertDialog.Builder(this).setView(box).setPositiveButton("شروع پازل",(x,w)->{int pieces=Integer.parseInt(vals[sp.getSelectedItemPosition()]);startPuzzle(path,pieces);}).setNegativeButton("انصراف",null).show();
    }
    void startPuzzle(String path,int pieces){try{Bitmap bm=BitmapFactory.decodeFile(path);int[] rc=gridFor(pieces,bm.getWidth(),bm.getHeight());getSharedPreferences("puzzle",0).edit().clear().putString("imagePath",path).putInt("rows",rc[0]).putInt("cols",rc[1]).apply(); puzzle=new PuzzleView(this,bm,rc[0],rc[1],true);setContentView(puzzle);}catch(Exception e){Toast.makeText(this,"شروع پازل ممکن نشد",Toast.LENGTH_SHORT).show();}}
    void loadSaved(){try{String p=getSharedPreferences("puzzle",0).getString("imagePath","");Bitmap bm=BitmapFactory.decodeFile(p);int r=getSharedPreferences("puzzle",0).getInt("rows",2),c=getSharedPreferences("puzzle",0).getInt("cols",2);puzzle=new PuzzleView(this,bm,r,c,false);setContentView(puzzle);}catch(Exception e){Toast.makeText(this,"ذخیره بازی پیدا نشد",Toast.LENGTH_SHORT).show();}}
    int[] gridFor(int n,int w,int h){double target=(double)w/h;int bestR=1,bestC=n;double err=999;for(int r=1;r<=n;r++)if(n%r==0){int c=n/r;double e=Math.abs(((double)c/r)-target);if(e<err){err=e;bestR=r;bestC=c;}}return new int[]{bestR,bestC};}
    void saveCompleted(Bitmap b){try{String name="PuzzleBahar_"+System.currentTimeMillis()+".jpg";OutputStream out;if(Build.VERSION.SDK_INT>=29){ContentValues v=new ContentValues();v.put(MediaStore.Images.Media.DISPLAY_NAME,name);v.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");v.put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/PuzzleBahar");Uri u=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v);out=getContentResolver().openOutputStream(u);}else{File dir=new File(getExternalFilesDir(null),"Completed");dir.mkdirs();out=new FileOutputStream(new File(dir,name));}b.compress(Bitmap.CompressFormat.JPEG,95,out);out.close();Toast.makeText(this,"پازل کامل شد و ذخیره شد 🌸",Toast.LENGTH_LONG).show();}catch(Exception e){Toast.makeText(this,"ذخیره تصویر انجام نشد",Toast.LENGTH_SHORT).show();}}
    @Override public void onBackPressed(){if(puzzle!=null){puzzle.persist();puzzle=null;showHome();}else super.onBackPressed();}
}
